import requests
from datetime import datetime
import pandas as pd
from sqlalchemy import create_engine, Table, Column, Integer, String, MetaData, Float, DateTime
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy import DECIMAL
from sqlalchemy.ext.declarative import declarative_base

# Define URL base of the API
base_url = "https://coinlib.io/api/v1"
endpoint = "/coin"

# Symbols of cryptocurrencies
symbols = ['BTC', 'ETH', 'XRP', 'LTC', 'BCH', 'ADA', 'DOT', 'UNI', 'LINK', 'XLM']

# Define the connection to Redshift
redshift_conn_str = 'redshift+psycopg2://villenafacundo_coderhouse:Q73b9f25jX@data-engineer-cluster.cyhh5bfevlmn.us-east-1.redshift.amazonaws.com:5439/data-engineer-database'
engine = create_engine(redshift_conn_str)
Base = declarative_base()

class Crypto(Base):
    __tablename__ = 'crypto_table'
    
    symbol = Column(String, primary_key=True)
    show_symbol = Column(String)
    name = Column(String)
    rank = Column(Integer)
    price = Column(DECIMAL)
    market_cap = Column(DECIMAL)
    total_volume_24h = Column(DECIMAL)
    low_24h = Column(DECIMAL)
    high_24h = Column(DECIMAL)
    delta_1h = Column(String)
    delta_24h = Column(String)
    delta_7d = Column(String)
    delta_30d = Column(String)
    last_updated_timestamp = Column(String)
    remaining = Column(String)
    date = Column(DateTime, primary_key=True)

def fetch_crypto_data(symbols, api_key):
    all_data = []

    for symbol in symbols:
        params = {
            'key': api_key,
            'pref': 'USD',
            'symbol': symbol
        }

        response = requests.get(base_url + endpoint, params=params)
        data = response.json()

        filtered_item = {k: data[k] for k in data.keys() & {
            'symbol', 'show_symbol', 'name', 'rank', 'price', 'market_cap', 'total_volume_24h',
            'low_24h', 'high_24h', 'delta_1h', 'delta_24h', 'delta_7d', 'delta_30d',
            'last_updated_timestamp', 'remaining'}}
        filtered_item['date'] = datetime.now()

        all_data.append(filtered_item)

    return pd.DataFrame(all_data)

def run_etl():
    df = fetch_crypto_data(symbols, '88cf380abc864341')
    df.to_sql('crypto_table', engine, if_exists='replace', index=False)
